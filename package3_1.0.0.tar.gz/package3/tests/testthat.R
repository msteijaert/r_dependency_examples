library(testthat)
library(package3)

test_check("package3")
