#' Nonsense
#' 
#' This function does absolutely nothing... well it returns an invisible NULL
#' @return invisble NULL
#' @export
nonsense <- function(){
	invisible(NULL)
}


